## Module <hr_employee_shift>

#### 15.10.2020
#### Version 15.0.1.0.0
##### ADD
- Initial commit for OpenHrms Project
